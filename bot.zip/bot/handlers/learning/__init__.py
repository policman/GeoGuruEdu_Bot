from .registration import router as learning_router
__all__ = ["learning_router"]
