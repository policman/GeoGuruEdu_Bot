from .registration import router as materials_router

__all__ = ["materials_router"]
