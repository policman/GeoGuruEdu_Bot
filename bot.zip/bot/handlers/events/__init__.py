from .registration import router
__all__ = ["router"]
from .visit import router as visit_event_router
# ...
router.include_router(visit_event_router)
