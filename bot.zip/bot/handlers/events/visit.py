from aiogram import Router
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from bot.states.event_states import VisitEvent
from bot.keyboards.events.visit_event import visit_event_keyboard

router = Router()

@router.message(lambda m: m.text == "Посетить событие")
async def handle_visit_event_menu(message: Message, state: FSMContext):
    await state.set_state(VisitEvent.menu)
    await message.answer(
        "Раздел посещения событий. Выберите действие:",
        reply_markup=visit_event_keyboard
    )

@router.message(StateFilter(VisitEvent.menu), lambda m: m.text == "Список доступных событий")
async def handle_show_event_list(message: Message, state: FSMContext):
    await state.set_state(VisitEvent.show_list)
    # ТУТ: Получи список событий из БД, например, events = await event_service.get_public_events(user_id)
    await message.answer(
        "Тут будет список доступных для посещения событий (реализуй вывод сам).\nДля возврата нажми ⬅️ Назад.",
        reply_markup=visit_event_keyboard
    )

@router.message(StateFilter(VisitEvent.menu), lambda m: m.text == "Поиск")
async def handle_search_events(message: Message, state: FSMContext):
    await state.set_state(VisitEvent.search)
    await message.answer("Введите поисковый запрос для поиска событий:", reply_markup=ReplyKeyboardRemove())

@router.message(StateFilter(VisitEvent.search))
async def handle_search_query(message: Message, state: FSMContext):
    query = message.text
    # ТУТ: Получи результаты поиска по БД, например, results = await event_service.search_events(query)
    await message.answer(f"Результаты поиска по '{query}': (реализуй вывод сам)", reply_markup=visit_event_keyboard)
    await state.set_state(VisitEvent.menu)

@router.message(StateFilter(VisitEvent.menu), lambda m: m.text == "Пойду")
async def handle_my_events(message: Message, state: FSMContext):
    await state.set_state(VisitEvent.my_events)
    # ТУТ: Получи список событий, на которые пользователь уже собирается пойти
    await message.answer(
        "Список событий, на которые вы собираетесь пойти (реализуй вывод сам).",
        reply_markup=visit_event_keyboard
    )

@router.message(StateFilter(VisitEvent.menu), lambda m: m.text.startswith("Приглашения"))
async def handle_my_invitations(message: Message, state: FSMContext):
    await state.set_state(VisitEvent.invitations)
    # ТУТ: Получи список приглашений из БД (pending)
    await message.answer(
        "Ваши приглашения на события. Для каждого — 'Принять' или 'Отклонить'. (реализуй вывод сам)",
        reply_markup=visit_event_keyboard
    )

@router.message(StateFilter(VisitEvent.menu), lambda m: m.text == "⬅️ Назад")
async def handle_back_to_main(message: Message, state: FSMContext):
    await state.clear()
    # Импортируй и вызови функцию показа главного меню:
    from bot.handlers.menu import show_main_menu
    await show_main_menu(message, state)
