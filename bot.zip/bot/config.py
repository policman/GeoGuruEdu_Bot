import os
from dotenv import load_dotenv

load_dotenv()

# Обязательные
BOT_TOKEN = os.getenv("BOT_TOKEN")
DATABASE_URL = os.getenv("DATABASE_URL")

# Проверка наличия
missing = []

if not BOT_TOKEN:
    missing.append("BOT_TOKEN")
if not DATABASE_URL:
    missing.append("DATABASE_URL")

if missing:
    missing_vars = ", ".join(missing)
    raise EnvironmentError(f"❌ Отсутствуют обязательные переменные в .env: {missing_vars}")
