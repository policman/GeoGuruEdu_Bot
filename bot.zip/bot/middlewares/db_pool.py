from aiogram import BaseMiddleware
import logging

logger = logging.getLogger("db_pool_middleware")

class DbConnectionMiddleware(BaseMiddleware):
    def __init__(self, db_pool):
        super().__init__()
        self.db_pool = db_pool

    async def __call__(self, handler, event, data):
        logger.debug("DbConnectionMiddleware: acquiring connection for event")
        try:
            async with self.db_pool.acquire() as conn:
                logger.debug("DbConnectionMiddleware: acquired connection")
                data["conn"] = conn
                return await handler(event, data)
        except Exception as e:
            logger.error("DbConnectionMiddleware: failed to acquire connection: %s", e)
            raise
