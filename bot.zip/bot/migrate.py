import asyncio
from run_migrations import main as run_migration

if __name__ == "__main__":
    asyncio.run(run_migration())
